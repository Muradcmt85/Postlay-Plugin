<?php

 /**
 * ncmbp Adds a submenu page under a custom post type parent.
 */

function ncmbp_register_page() {
    add_submenu_page( 
        'edit.php?post_type=ncmbp',
        __( 'Settings', 'ncmbp' ),
        __( 'PostLay Settings', 'ncmbp' ),
        'manage_options',
        'ncmbp-settings-pages',
        'ncmbp_page_callback'
    );
}

add_action('admin_menu', 'ncmbp_register_page');
 
/**
 * Display callback for the submenu page.
 */
function ncmbp_page_callback() { 
    ?>
    <div class="ncmbp__admin_wrap wrap">
        <div class="ncmbp_left_style">
            <h1><?php _e( 'PostLay Settings', 'ncmbp' ); ?></h1>
            <form action="options.php" method="post">
                <?php wp_nonce_field('update-options');?>
                <div class="ncmbp__dashboard_options">
                    <label name="title_color" for="title_color"><?php echo esc_attr(__('PostLay Title Color: ')); ?></label>
                    <input type="text" id="color_code" class="my-color-field" name="title_color" value="<?php echo esc_attr(get_option('title_color'));?>">
                </div>
                
                <div class="ncmbp__dashboard_options">
                    <label name="details_color" for="details_color"><?php echo esc_attr(__('PostLay Paragraph Color ')); ?></label>
                    <input type="text" class="my-color-field" name="details_color" value="<?php echo esc_attr(get_option('details_color'));?>">
                </div>

                <div class="ncmbp__dashboard_options">
                    <label name="ncmbp__pagination_color" for="ncmbp__pagination_color"><?php echo esc_attr(__('Pagination Background Color ')); ?></label>
                    <input type="text" class="my-color-field" name="ncmbp__pagination_color" value="<?php echo esc_attr(get_option('ncmbp__pagination_color'));?>">
                </div>

                <div class="ncmbp__dashboard_options">
                    <label name="ncmbp__pagination_Hovercolor" for="ncmbp__pagination_Hovercolor"><?php echo esc_attr(__('Pagination Hover Color ')); ?></label>
                    <input type="text" class="my-color-field" name="ncmbp__pagination_Hovercolor" value="<?php echo esc_attr(get_option('ncmbp__pagination_Hovercolor'));?>">
                </div>

                <div class="ncmbp__dashboard_options">
                    <label name="ncmbp__pagination_Fontcolor" for="ncmbp__pagination_Fontcolor"><?php echo esc_attr(__('Pagination Text Color ')); ?></label>
                    <input type="text" class="my-color-field" name="ncmbp__pagination_Fontcolor" value="<?php echo esc_attr(get_option('ncmbp__pagination_Fontcolor'));?>">
                </div>

                <div class="ncmbp__dashboard_options">
                    <label name="ncmbp__Btn_bgColor" for="ncmbp__Btn_bgColor"><?php echo esc_attr(__('Button Background Color ')); ?></label>
                    <input type="text" class="my-color-field" name="ncmbp__Btn_bgColor" placeholder="#01A6FE" value="<?php echo esc_attr(get_option('ncmbp__Btn_bgColor'));?>">
                </div>

                <div class="ncmbp__dashboard_options">
                    <label name="ncmbp__Btn_borderColor" for="ncmbp__Btn_borderColor"><?php echo esc_attr(__('Button Border Color ')); ?></label>
                    <input type="text" class="my-color-field" name="ncmbp__Btn_borderColor" placeholder="#01A6FE" value="<?php echo esc_attr(get_option('ncmbp__Btn_borderColor'));?>">
                </div>

                <div class="ncmbp__dashboard_options">
                    <label name="ncmbp__Btn_textColor" for="ncmbp__Btn_textColor"><?php echo esc_attr(__('Button Text Color ')); ?></label>
                    <input type="text" class="my-color-field" name="ncmbp__Btn_textColor" placeholder="#01A6FE" value="<?php echo esc_attr(get_option('ncmbp__Btn_textColor'));?>">
                </div>

                
                <div class="ncmbp__dashboard_options">
                    <label name="ncmbp__Btn_hvfontColor" for="ncmbp__Btn_hvfontColor"><?php echo esc_attr(__('Button Hover Text Color ')); ?></label>
                    <input type="text" name="ncmbp__Btn_hvfontColor" class="my-color-field" placeholder="#ffffff" value="<?php echo esc_attr(get_option('ncmbp__Btn_hvfontColor'));?>">
                </div>

                <div class="ncmbp__dashboard_options">
                    <label name="ncmbp__Btn_HoverColor" for="ncmbp__Btn_HoverColor"><?php echo esc_attr(__('Button Hover BG Color ')); ?></label>
                    <input type="text" name="ncmbp__Btn_HoverColor" class="my-color-field" placeholder="#333333" value="<?php echo esc_attr(get_option('ncmbp__Btn_HoverColor'));?>">
                </div>

                <div class="ncmbp__dashboard_options">
                    <label name="ncmbp__Btn_HoverborderColor" for="ncmbp__Btn_HoverborderColor"><?php echo esc_attr(__('Button Hover Border Color ')); ?></label>
                    <input type="text" name="ncmbp__Btn_HoverborderColor" class="my-color-field" placeholder="#333333" value="<?php echo esc_attr(get_option('ncmbp__Btn_HoverborderColor'));?>">
                </div>

                <div class="ncmbp__dashboard_options">
                    <label name="title_font_size" for="title_font_size"><?php echo esc_attr(__('Title Font Size: ')); ?></label>
                    <input type="text" name="title_font_size" placeholder="25px" value="<?php echo esc_attr(get_option('title_font_size'));?>">
                </div>
                
                <div class="ncmbp__dashboard_options">
                    <label name="paragraph_font_size" for="paragraph_font_size"><?php echo esc_attr(__('Paragraph Font Size ')); ?></label>
                    <input type="text" name="paragraph_font_size" placeholder="18px" value="<?php echo esc_attr(get_option('paragraph_font_size'));?>">
                </div>
                
                <div class="ncmbp__dashboard_options">
                    <label name="ncmbp_font__family" for="ncmbp_font__family"><?php echo esc_attr(__('Change Font Family ')); ?></label>
                    <input type="text" name="ncmbp_font__family" placeholder="Signika Negative" value="<?php echo esc_attr(get_option('ncmbp_font__family'));?>">
                </div>

                <div class="ncmbp__dashboard_options">
                    <label name="ncmbp__blog_column_padding" for="ncmbp__blog_column_padding"><?php echo esc_attr(__('Blog Column Padding ')); ?></label>
                    <input type="text" name="ncmbp__blog_column_padding" placeholder="15px"  value="<?php echo esc_attr(get_option('ncmbp__blog_column_padding'));?>">
                </div>

                <div class="ncmbp__dashboard_options">
                    <label name="ncmbp__blog_posts_number" for="ncmbp__blog_posts_number"><?php echo esc_attr(__('Blog Posts Show Numbers ')); ?></label>
                    <input type="text" name="ncmbp__blog_posts_number" placeholder="6"  value="<?php echo esc_attr(get_option('ncmbp__blog_posts_number'));?>">
                </div>

               
                <div class="ncmbp__dashboard_options">
                    <label name="ncmbp__column_shadow" for="ncmbp__column_shadow"><?php echo esc_attr(__('Column Box Shadow: ')); ?></label>
                    <input type="text" name="ncmbp__column_shadow" placeholder="1px 1px 3px 2px #f4f5f6" value="<?php echo esc_attr(get_option('ncmbp__column_shadow'));?>">
                </div>

                <div class="ncmbp__dashboard_options">
                    <label name="ncmbp__column_borderRadius" for="ncmbp__column_borderRadius"><?php echo esc_attr(__('Column Border Radius ')); ?></label>
                    <input type="text" name="ncmbp__column_borderRadius" placeholder="0px" value="<?php echo esc_attr(get_option('ncmbp__column_borderRadius'));?>">
                </div>

                <div class="ncmbp__dashboard_options">
                    <label name="ncmbp__Featureimg_borderRadius" for="ncmbp__Featureimg_borderRadius"><?php echo esc_attr(__('Feature Image Border Radius ')); ?></label>
                    <input type="text" name="ncmbp__Featureimg_borderRadius" placeholder="0px" value="<?php echo esc_attr(get_option('ncmbp__Featureimg_borderRadius'));?>">
                </div>

                <div class="ncmbp__dashboard_options">
                    <label name="ncmbp__Btn_borderRadius" for="ncmbp__Btn_borderRadius"><?php echo esc_attr(__('Button Border Radius ')); ?></label>
                    <input type="text" name="ncmbp__Btn_borderRadius" placeholder="0px" value="<?php echo esc_attr(get_option('ncmbp__Btn_borderRadius'));?>">
                </div>

                <div class="ncmbp__dashboard_options">
                    <label name="ncmbp__Pagination_borderRadius" for="ncmbp__Pagination_borderRadius"><?php echo esc_attr(__('Pagination Border Radius ')); ?></label>
                    <input type="text" name="ncmbp__Pagination_borderRadius" placeholder="0px" value="<?php echo esc_attr(get_option('ncmbp__Pagination_borderRadius'));?>">
                </div>

                <input type="hidden" name="action" value="update"/>
                <input type="hidden" name="page_options" value="title_color, details_color,title_font_size,paragraph_font_size,ncmbp__blog_column_padding,ncmbp__blog_posts_number,ncmbp__pagination_color,ncmbp__pagination_Hovercolor,ncmbp__pagination_Fontcolor,ncmbp__column_borderRadius,ncmbp__Featureimg_borderRadius,ncmbp__column_shadow,ncmbp__Btn_borderRadius,ncmbp__Pagination_borderRadius,ncmbp_font__family,ncmbp__Btn_bgColor,ncmbp__Btn_hvfontColor,ncmbp__Btn_borderColor,ncmbp__Btn_textColor,ncmbp__Btn_HoverColor,ncmbp__Btn_HoverborderColor"/>
                <input type="submit" name="submit" value="<?php _e('Save Changes', 'netoricstp')?>">
            </form>
        </div>
        <div class="ncmbp__right_style">
            <h1><?php echo esc_attr('About The Author');?></h1>
            <p><?php echo esc_attr('Netro Soft is a end-to-end App and Plugin developer company. We focus on user experience as well as user feasibility. We started from solving a particular problem and we are still continuing our hard work to deliver something better.');?><br /><br />
            <strong><?php echo esc_attr('Email:');?></strong> <?php echo esc_attr(' contact@netroics.com');?><br />
            <strong><?php echo esc_attr('Web:');?></strong> <a href="https://netroics.com/" target="_blank"><b><?php echo esc_attr('www.netroics.com');?></b></a><br />
            
            </p>
        </div>
    </div>
    <?php
}